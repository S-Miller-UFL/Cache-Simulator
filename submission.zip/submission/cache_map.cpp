#include "cache_map.h"

void cache::init_cache(int, int)
{
}
